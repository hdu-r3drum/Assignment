import os
import torch.nn as nn
import matplotlib.pyplot as plt

def mkdir(path):
    """
    Create a single empty directory if it didn't exist.
    """
    if not os.path.exists(path):
        os.makedirs(path)

def weights_init(m):
    """
    This function initializes the model weights randomly from a
    Normal distribution. This follows the specification from the DCGAN paper.
    https://arxiv.org/pdf/1511.06434.pdf
    """
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find('BatchNorm') != -1:
        nn.init.normal_(m.weight.data, 1.0, 0.02)
        nn.init.constant_(m.bias.data, 0)

def plot_loss(loss_D, loss_G, save_path):
    """
    Plot generator and discriminator loss curve.
    """
    plt.figure(figsize=(15, 7))
    plt.title("Generator and Discriminator Loss During Training")
    plt.plot(loss_D, label="D")
    plt.plot(loss_G, label="G")
    plt.xlabel("iterations")
    plt.ylabel("Loss")
    plt.legend(['loss_D', 'loss_G'])
    plt.savefig(save_path)