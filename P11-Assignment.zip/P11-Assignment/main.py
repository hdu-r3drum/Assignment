import argparse
import os

import torch
import numpy as np

from torchvision import datasets
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.utils import save_image

from networks import Generator, Discriminator
from utils import *

# Set arguments and parameters
parser = argparse.ArgumentParser()
parser.add_argument('--batch_size', type=int, default=64, help='the number of examples in each batch')
parser.add_argument('--lr', type=float, default=0.0002, help='learning rate')
parser.add_argument('--beta1', type=float, default=0.5, help='adam: decay of first order momentum of gradient')
parser.add_argument('--beta2', type=float, default=0.999, help='adam: decay of first order momentum of gradient')
parser.add_argument('--n_classes', type=int, default=10, help='number of classes for dataset')
parser.add_argument('--channels', type=int, default=3, help='number of image channels')
parser.add_argument('--ngf', type=int, default=64, help='size of feature maps in netG')
parser.add_argument('--ndf', type=int, default=64, help='size of feature maps in netD')
parser.add_argument('--latent_dim', type=int, default=100, help='dimensionality of the latent space')
parser.add_argument('--img_size', type=int, default=64, help='size of each image dimension')
parser.add_argument('--n_epoch', type=int, default=50, help='number of epochs of training')
parser.add_argument('--n_row', type=int, default=10, help='the now of labels')
parser.add_argument('--save_freq', type=int, default=1, help='save a model every save_freq epochs')
parser.add_argument('--gpu_ids', type=int, default=0, help='enables cuda')
parser.add_argument('--ngpu', type=int, default=1, help='number of GPUs available. Use 0 for CPU mode')
parser.add_argument('--dataroot', type=str, default='./datasets/CIFAR10', help='path to datasets')
parser.add_argument('--checkpoints_dir', type=str, default='./checkpoints', help='models are saved here')
args = parser.parse_args()
print(args)

# Set save path
save_fig_path = os.path.join(args.checkpoints_dir, 'figs')
save_model_path = os.path.join(args.checkpoints_dir, 'models')
save_loss_path = os.path.join(args.checkpoints_dir, 'loss')

# Create folder for saving datasets, images and models
mkdir(args.dataroot)
mkdir(save_fig_path)
mkdir(save_model_path)
mkdir(save_loss_path)


### Dataset ###
# Create the dataset
train_data = datasets.CIFAR10(args.dataroot, train=True, download=True,
                              transform=transforms.Compose([transforms.Resize(args.img_size),
                                                            transforms.ToTensor(),
                                                            transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))]))
# Create the dataloader
train_loader = DataLoader(train_data, batch_size=args.batch_size, shuffle=True, drop_last=True)


### Model ###
# Decide which device we want to run on
device = torch.device("cuda:0" if (torch.cuda.is_available() and args.ngpu > 0) else "cpu")

# Create the generator and discriminator
netG = Generator(args.latent_dim, args.channels, args.ngf).to(device)
netD = Discriminator(args.channels, args.ndf).to(device)

# Apply the weights_init function to randomly initialize all weights to mean=0, stdev=0.02.
netG.apply(weights_init)
netD.apply(weights_init)

# Print the model
print(netG, netD)

### Training ###

### Define Loss Function ###
# Initialize BCELoss function
criterion = nn.BCELoss()


### Define Optimizer ###
# Setup Adam optimizers for both generator and discriminator
optimizer_G = torch.optim.Adam(netG.parameters(), lr = args.lr, betas = (args.beta1, args.beta2))
optimizer_D = torch.optim.Adam(netD.parameters(), lr = args.lr, betas = (args.beta1, args.beta2))


print('Start Training ...')
losses_D = []
losses_G = []
# For each epoch
for epoch in range(args.n_epoch):
    # For each batch in the dataloader
    for i, (image, _) in enumerate(train_loader):

        ############################
        # Update D network: maximize log(D(x)) + log(1 - D(G(z)))
        ###########################
        optimizer_D.zero_grad()

        ### Train with real batch ###
        # Get real image from dataset
        real_image = image.to(device)
        # Create real labels (ones)
        real_label = torch.ones(args.batch_size).to(device)

        # Get output by doing real image forward pass
        dis_real = netD(real_image)
        loss_D_real = criterion(dis_real, real_label)

        ### Train with fake batch ###
        # Generate batch of latent vectors
        noise = torch.randn(args.batch_size, args.latent_dim, 1, 1).to(device)
        # Generate fake image with generator
        fake_image = netG(noise)
        # Create fake labels (zeros)
        fake_label = torch.zeros(args.batch_size).to(device)

        # Get output by doing fake image forward pass
        dis_fake = netD(fake_image.detach())
        loss_D_fake = criterion(dis_fake, fake_label)

        # Compute the total loss
        loss_D = (loss_D_real + loss_D_fake) / 2
        loss_D.backward()

        # Update discriminator
        optimizer_D.step()


        ############################
        # Update G network: maximize log(D(G(z)))
        ###########################
        optimizer_G.zero_grad()

        # Get output by doing fake image forward pass
        gen_fake = netD(fake_image)

        # Compute loss
        loss_G = criterion(gen_fake, real_label)
        loss_G.backward()

        # Update generator
        optimizer_G.step()

        # Save losses for plot
        losses_D.append(loss_D.item())
        losses_G.append(loss_G.item())

        print("[Epoch: %d/%d] [Batch: %d/%d] [D loss: %.3f] [G loss: %.3f]"
              % (epoch, args.n_epoch, i, len(train_loader), loss_D.item(), loss_G.item()))

    # Save image and model
    if epoch % args.save_freq == 0:
        noise = torch.randn(args.n_row ** 2, args.latent_dim, 1, 1).to(device)
        gen_image = netG(noise)
        gen_img = gen_image.view(args.n_row ** 2, args.channels, args.img_size, args.img_size)
        save_image(gen_img.data, '%s/%d_generated_image.png' % (save_fig_path, epoch), nrow=args.n_row, normalize=True)
        torch.save(netG.state_dict(), '%s/%d_netG.pkl' % (save_model_path, epoch))
        plot_loss(losses_D, losses_G, '%s/%d_epoch.png' % (save_loss_path, epoch))