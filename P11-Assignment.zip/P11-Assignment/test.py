import argparse
import os

import torch
import numpy as np

from torchvision import datasets
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from torchvision.utils import save_image

from networks import Generator
from utils import *

# Set arguments and parameters
parser = argparse.ArgumentParser()
parser.add_argument('--batch_size', type=int, default=1, help='the number of examples in each batch')
parser.add_argument('--lr', type=float, default=0.0002, help='learning rate')
parser.add_argument('--beta1', type=float, default=0.5, help='adam: decay of first order momentum of gradient')
parser.add_argument('--beta2', type=float, default=0.999, help='adam: decay of first order momentum of gradient')
parser.add_argument('--n_classes', type=int, default=10, help='number of classes for dataset')
parser.add_argument('--channels', type=int, default=3, help='number of image channels')
parser.add_argument('--ngf', type=int, default=64, help='size of feature maps in netG')
parser.add_argument('--ndf', type=int, default=64, help='size of feature maps in netD')
parser.add_argument('--latent_dim', type=int, default=100, help='dimensionality of the latent space')
parser.add_argument('--img_size', type=int, default=64, help='size of each image dimension')
parser.add_argument('--n_row', type=int, default=10, help='the now of labels')
parser.add_argument('--gpu_ids', type=int, default=0, help='enables cuda')
parser.add_argument('--ngpu', type=int, default=1, help='number of GPUs available. Use 0 for CPU mode')
parser.add_argument('--dataroot', type=str, default='./datasets/CIFAR10', help='path to datasets')
parser.add_argument('--model_path', type=str, default='./checkpoints/models/10_netG.pkl', help='model for testing')
parser.add_argument('--results_dir', type=str, default='./results', help='store test results')
args = parser.parse_args()
print(args)

# Create folder for saving datasets, images and models
mkdir(args.dataroot)
mkdir(args.results_dir)


### Dataset ###
# Create the dataset
test_data = datasets.CIFAR10(args.dataroot, train=False, download=True,
                              transform=transforms.Compose([transforms.Resize(args.img_size),
                                                            transforms.ToTensor(),
                                                            transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))]))
# Create the dataloader
test_loader = DataLoader(test_data, batch_size=args.batch_size, shuffle=False)


### Model ###
# Decide which device we want to run on
device = torch.device("cuda:0" if (torch.cuda.is_available() and args.ngpu > 0) else "cpu")

# Create the generator
netG = Generator(args.latent_dim, args.channels, args.ngf).to(device)
# Load model
netG.load_state_dict(torch.load(args.model_path))
# Print the model
print(netG)

### Testing ###
print('Start Testing ...')
netG.eval()
# For each batch in the dataloader
for i, (image, _) in enumerate(test_loader):
    # Real image
    real_image = image.to(device)

    # Generate fake image
    noise = torch.randn(args.batch_size, args.latent_dim, 1, 1).to(device)
    fake_image = netG(noise)

    print("[Batch %d/%d]" % (i, len(test_loader)))

    real_fake_image = torch.cat((real_image, fake_image), dim=-1)
    save_image(real_fake_image.data, '%d.png' % i, nrow=args.batch_size, normalize=True)
