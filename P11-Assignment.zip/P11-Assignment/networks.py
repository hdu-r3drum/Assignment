import torch.nn as nn

class Generator(nn.Module):
    def __init__(self, latent_dim, channels, ngf):
        super(Generator, self).__init__()
        self.convT1 = nn.Sequential(
            nn.ConvTranspose2d(latent_dim, ngf * 16, kernel_size=4, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(ngf * 16),
            nn.ReLU(inplace=True)
        )

        self.convT2 = nn.Sequential(
            nn.ConvTranspose2d(ngf * 16, ngf * 8, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ngf * 8),
            nn.ReLU(inplace=True)
        )

        self.convT3 = nn.Sequential(
            nn.ConvTranspose2d(ngf * 8, ngf * 4, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ngf * 4),
            nn.ReLU(inplace=True)
        )

        self.convT4 = nn.Sequential(
            nn.ConvTranspose2d(ngf * 4, ngf * 2, 4, 2, 1, bias=False),
            nn.BatchNorm2d(ngf * 2),
            nn.ReLU(inplace=True)
        )

        self.convT5 = nn.Sequential(
            nn.ConvTranspose2d(ngf * 2, channels, 4, 2, 1, bias=False),
            nn.Tanh()
        )


    def forward(self, inputs):
        output1 = self.convT1(inputs)
        output2 = self.convT2(output1)
        output3 = self.convT3(output2)
        output4 = self.convT4(output3)
        output5 = self.convT5(output4)
        return output5


class Discriminator(nn.Module):
    def __init__(self, channels, ndf):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            # channels * 64 * 64->64*32*32
            nn.Conv2d(channels, ndf, kernel_size=4, stride=2, padding=1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            # 64*32*32->128*16*16
            nn.Conv2d(ndf, ndf * 2, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(ndf * 2),
            nn.LeakyReLU(0.2, inplace=True),
            # 128*16*16->256*8*8
            nn.Conv2d(ndf * 2, ndf * 4, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(ndf * 4),
            nn.LeakyReLU(0.2, inplace=True),
            # 256*8*8->512*4*4
            nn.Conv2d(ndf * 4, ndf * 8, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(ndf * 8),
            nn.LeakyReLU(0.2, inplace=True),
            # 512 * 4 * 4 -> 1*1*1
            nn.Conv2d(ndf * 8, 1, kernel_size=4, stride=1, padding=0, bias=False),
            nn.Sigmoid()
        )


    def forward(self, image):
        output = self.model(image)
        output = output.view(-1)
        return output